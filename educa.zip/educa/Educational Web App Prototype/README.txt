LA PROPIEDAD INTELECTUAL DE ESTE PROGRAMA PROGRAMA PERTENECE A LAS PERSONAS:
González Hernández Stefani
Gomez Ahumada Luis Eduardo
Hernández Peña Carlos
Hernández Lopez Rubén Emilio
Vazquez Arellano Natasha Adali
 ESTE MISMO PROGRAMA SE ENCUENTRA RESGUARDADO EN LAPAGINA DE FIGMA Y GITHUB
 https://github.com/Mskeyk/educational-web.git
https://www.figma.com/community/file/1586460801173779921
