import { Button } from "./ui/button";
import type { User } from "../App";
import { getStatistics, getTopStudents, getRecentResults } from "../utils/storage";
import { useEffect, useState } from "react";

interface ProfessorDashboardProps {
  user: User;
  onLogout: () => void;
  onSwitchToStudentMode: () => void;
}

export default function ProfessorDashboard({ user, onLogout, onSwitchToStudentMode }: ProfessorDashboardProps) {
  const [stats, setStats] = useState(() => getStatistics());
  const [topStudents, setTopStudents] = useState(() => getTopStudents(5));
  const [recentResults, setRecentResults] = useState(() => getRecentResults(5));

  useEffect(() => {
    // Refresh data on mount
    setStats(getStatistics());
    setTopStudents(getTopStudents(5));
    setRecentResults(getRecentResults(5));
  }, []);

  // Use real data if available, otherwise show default message
  const hasData = stats.totalStudents > 0;

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="bg-[#1A5490] text-white py-4 px-6 flex items-center justify-between">
        <div>
          <h1 className="mb-1">Interactivamente</h1>
          <p className="text-sm opacity-90">Modo: Profesor</p>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-sm">Bienvenido/a, {user.name}</span>
          <Button
            onClick={onSwitchToStudentMode}
            variant="outline"
            className="bg-white/10 border-white/30 text-white hover:bg-white/20"
          >
            Ver como estudiante
          </Button>
          <Button
            onClick={onLogout}
            variant="outline"
            className="bg-white/10 border-white/30 text-white hover:bg-white/20"
          >
            Cerrar Sesión
          </Button>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto p-8">
        <div className="mb-8">
          <h2 className="text-[#1A5490] mb-2">Panel de Control del Profesor</h2>
          <p className="text-gray-600">Monitorea el progreso y rendimiento de tus estudiantes</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-gradient-to-br from-[#7B2CBF] to-[#9D4EDD] text-white rounded-2xl p-6 shadow-lg">
            <p className="text-sm opacity-90 mb-2">Estudiantes Registrados</p>
            <p className="mb-1">{stats.totalStudents}</p>
            <p className="text-xs opacity-75">Total en el sistema</p>
          </div>

          <div className="bg-gradient-to-br from-[#4CAF50] to-[#66BB6A] text-white rounded-2xl p-6 shadow-lg">
            <p className="text-sm opacity-90 mb-2">Estudiantes Activos</p>
            <p className="mb-1">{stats.activeStudents}</p>
            <p className="text-xs opacity-75">Última semana</p>
          </div>

          <div className="bg-gradient-to-br from-[#2196F3] to-[#42A5F5] text-white rounded-2xl p-6 shadow-lg">
            <p className="text-sm opacity-90 mb-2">Promedio General</p>
            <p className="mb-1">{stats.groupAverage}%</p>
            <p className="text-xs opacity-75">De todos los temas</p>
          </div>

          <div className="bg-gradient-to-br from-[#FF9800] to-[#FFA726] text-white rounded-2xl p-6 shadow-lg">
            <p className="text-sm opacity-90 mb-2">Visitas Recientes</p>
            <p className="mb-1">{stats.recentVisits}</p>
            <p className="text-xs opacity-75">Últimas 24 horas</p>
          </div>
        </div>

        {/* Two Column Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Top Students */}
          <div className="bg-white rounded-2xl p-6 shadow-lg">
            <h3 className="text-[#1A5490] mb-4">🏆 Top Estudiantes</h3>
            {topStudents.length > 0 ? (
              <div className="space-y-3">
                {topStudents.map((student, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-3 bg-gradient-to-r from-[#A8E6E3] to-[#C8F3F0] rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">
                        {index === 0 ? "🥇" : index === 1 ? "🥈" : index === 2 ? "🥉" : "⭐"}
                      </span>
                      <div>
                        <p className="text-sm text-gray-800">{student.name}</p>
                        <p className="text-xs text-gray-600">{student.topic}</p>
                      </div>
                    </div>
                    <span className="text-[#4CAF50]">{student.score}%</span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                <p className="mb-2">(｡◕‿◕｡)</p>
                <p className="text-sm">Aún no hay resultados de estudiantes</p>
              </div>
            )}
          </div>

          {/* Topic Statistics */}
          <div className="bg-white rounded-2xl p-6 shadow-lg">
            <h3 className="text-[#1A5490] mb-4">📊 Estadísticas por Tema</h3>
            {stats.topicStats.length > 0 ? (
              <div className="space-y-4">
                {stats.topicStats.map((stat, index) => (
                  <div key={index} className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-700">{stat.topic}</span>
                      <span className="text-sm text-gray-600">{stat.average}% · {stat.attempts} intentos</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
                      <div
                        className="bg-[#4CAF50] h-full rounded-full transition-all"
                        style={{ width: `${stat.average}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                <p className="mb-2">(◠‿◠)</p>
                <p className="text-sm">Aún no hay estadísticas por tema</p>
              </div>
            )}
          </div>
        </div>

        {/* Recent Results */}
        <div className="bg-white rounded-2xl p-6 shadow-lg">
          <h3 className="text-[#1A5490] mb-4">📝 Últimos Resultados</h3>
          {recentResults.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b-2 border-gray-200">
                    <th className="text-left py-3 px-4 text-sm text-gray-700">Estudiante</th>
                    <th className="text-left py-3 px-4 text-sm text-gray-700">Tema</th>
                    <th className="text-left py-3 px-4 text-sm text-gray-700">Puntuación</th>
                    <th className="text-left py-3 px-4 text-sm text-gray-700">Fecha</th>
                  </tr>
                </thead>
                <tbody>
                  {recentResults.map((result, index) => (
                    <tr key={index} className="border-b border-gray-100 hover:bg-gray-50">
                      <td className="py-3 px-4 text-sm">{result.name}</td>
                      <td className="py-3 px-4 text-sm text-gray-600">{result.topic}</td>
                      <td className="py-3 px-4">
                        <span
                          className={`inline-block px-3 py-1 rounded-full text-sm ${
                            result.score >= 80
                              ? "bg-green-100 text-green-700"
                              : result.score >= 60
                              ? "bg-blue-100 text-blue-700"
                              : "bg-orange-100 text-orange-700"
                          }`}
                        >
                          {result.score}%
                        </span>
                      </td>
                      <td className="py-3 px-4 text-sm text-gray-600">{result.date}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <p className="mb-2">(✿◠‿◠)</p>
              <p className="text-sm">Aún no hay resultados recientes</p>
              <p className="text-xs text-gray-400 mt-2">Usa el botón "Ver como estudiante" para probar el juego</p>
            </div>
          )}
        </div>

        {/* Info Box */}
        <div className="mt-8 p-6 bg-blue-50 rounded-2xl border-l-4 border-blue-500">
          <p className="text-blue-800 mb-3">
            💡 <strong>Datos actuales:</strong> Los resultados se guardan localmente en tu navegador. 
            Esto significa que solo verás los datos de los quizzes completados en este dispositivo.
          </p>
          <p className="text-sm text-blue-700">
            Para una versión completa con persistencia en la nube, múltiples usuarios, 
            y seguimiento real de estudiantes en diferentes dispositivos, 
            podrías conectar esta aplicación a una base de datos como Supabase.
          </p>
        </div>
      </div>
    </div>
  );
}