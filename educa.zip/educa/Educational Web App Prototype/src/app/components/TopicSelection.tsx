import { Button } from "./ui/button";
import type { User, Topic } from "../App";

interface TopicSelectionProps {
  user: User;
  onTopicSelect: (topic: Topic) => void;
  onLogout: () => void;
}

const topics = [
  {
    id: "antiderivadas" as Topic,
    title: "Antiderivadas",
    description: "Aprende las fórmulas básicas de integración",
    emoji: "(｡◕‿◕｡)"
  },
  {
    id: "partes" as Topic,
    title: "Integración por Partes",
    description: "Domina la técnica ∫u dv = uv - ∫v du",
    emoji: "(^▽^)"
  },
  {
    id: "trigonometrica" as Topic,
    title: "Sustitución Trigonométrica",
    description: "Resuelve integrales con funciones trigonométricas",
    emoji: "(◠‿◠)"
  },
  {
    id: "parciales" as Topic,
    title: "Fracciones Parciales",
    description: "Descompón fracciones racionales complejas",
    emoji: "(✿◠‿◠)"
  },
  {
    id: "definida" as Topic,
    title: "Integral Definida",
    description: "Calcula áreas bajo la curva",
    emoji: "(ﾉ◕ヮ◕)ﾉ*:･ﾟ✧"
  }
];

export default function TopicSelection({ user, onTopicSelect, onLogout }: TopicSelectionProps) {
  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="bg-[#1A5490] text-white py-4 px-6 flex items-center justify-between">
        <div>
          <h1 className="mb-1">Interactivamente</h1>
          <p className="text-sm opacity-90">Modo: Estudiante</p>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-sm">¡Hola, {user.name}!</span>
          <Button
            onClick={onLogout}
            variant="outline"
            className="bg-white/10 border-white/30 text-white hover:bg-white/20"
          >
            Cerrar Sesión
          </Button>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-6xl mx-auto p-8">
        <div className="text-center mb-8">
          <h2 className="text-[#1A5490] mb-2">Selecciona un tema para practicar</h2>
          <p className="text-gray-700">Elige el método de integración que quieres estudiar</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {topics.map((topic) => (
            <button
              key={topic.id}
              onClick={() => onTopicSelect(topic.id)}
              className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-1 text-left border-2 border-transparent hover:border-[#4CAF50]"
            >
              <div className="mb-4">
                <span className="block mb-3">{topic.emoji}</span>
                <h3 className="text-[#1A5490] mb-2">{topic.title}</h3>
                <p className="text-gray-600 text-sm">{topic.description}</p>
              </div>
              <div className="mt-4 text-[#4CAF50] flex items-center gap-2">
                <span>Comenzar</span>
                <span>→</span>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
