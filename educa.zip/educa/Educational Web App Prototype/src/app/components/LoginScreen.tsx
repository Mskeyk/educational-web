import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import type { UserRole } from "../App";

interface LoginScreenProps {
  onLogin: (role: UserRole, name: string, email: string) => void;
}

export default function LoginScreen({ onLogin }: LoginScreenProps) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simple demo logic - check if email contains "profesor" for professor role
    const role: UserRole = email.toLowerCase().includes("profesor") ? "professor" : "student";
    const name = email.split("@")[0];
    onLogin(role, name, email);
  };

  const handleDemoStudent = () => {
    onLogin("student", "Estudiante Demo", "estudiante@demo.com");
  };

  const handleDemoProfesor = () => {
    onLogin("professor", "Profesor Demo", "profesor@demo.com");
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="bg-[#1A5490] text-white py-6 px-8 rounded-t-2xl text-center">
          <h1 className="mb-2">Interactivamente</h1>
          <p className="opacity-90">Rutas de Integración</p>
        </div>

        {/* Login Form */}
        <div className="bg-white p-8 rounded-b-2xl shadow-lg">
          <h2 className="text-center mb-6 text-[#1A5490]">Iniciar Sesión</h2>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Input
                type="email"
                placeholder="Correo electrónico"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full border-2 border-gray-300 rounded-lg px-4 py-3"
                required
              />
            </div>
            
            <div>
              <Input
                type="password"
                placeholder="Contraseña"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full border-2 border-gray-300 rounded-lg px-4 py-3"
                required
              />
            </div>

            <Button
              type="submit"
              className="w-full bg-[#4CAF50] hover:bg-[#45a049] text-white py-3 rounded-lg transition-colors"
            >
              Iniciar sesión
            </Button>
          </form>

          <div className="mt-6 pt-6 border-t border-gray-200">
            <p className="text-center text-gray-600 mb-4">O ingresa como:</p>
            
            <div className="space-y-3">
              <Button
                onClick={handleDemoStudent}
                variant="outline"
                className="w-full border-2 border-[#1A5490] text-[#1A5490] hover:bg-[#1A5490] hover:text-white py-3 rounded-lg transition-colors"
              >
                Estudiante Demo
              </Button>
              
              <Button
                onClick={handleDemoProfesor}
                variant="outline"
                className="w-full border-2 border-[#7B2CBF] text-[#7B2CBF] hover:bg-[#7B2CBF] hover:text-white py-3 rounded-lg transition-colors"
              >
                Profesor Demo
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
