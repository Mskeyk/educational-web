import { useState, useEffect } from "react";
import { Button } from "./ui/button";
import { Progress } from "./ui/progress";
import type { User, Topic } from "../App";
import { saveQuizResult } from "../utils/storage";

interface QuizGameProps {
  topic: Topic;
  user: User;
  onQuizComplete: (score: number) => void;
  onLogout: () => void;
}

interface QuizQuestion {
  question: string;
  options: string[];
  correctAnswer: number;
}

const quizQuestions: Record<Topic, QuizQuestion[]> = {
  antiderivadas: [
    {
      question: "∫ x³ dx = ?",
      options: ["x⁴/4 + C", "3x² + C", "x²/2 + C", "4x⁴ + C"],
      correctAnswer: 0
    },
    {
      question: "∫ eˣ dx = ?",
      options: ["eˣ⁺¹ + C", "xeˣ + C", "eˣ + C", "eˣ/x + C"],
      correctAnswer: 2
    },
    {
      question: "∫ 1/x dx = ?",
      options: ["x² + C", "ln|x| + C", "1/x² + C", "e/x + C"],
      correctAnswer: 1
    },
    {
      question: "∫ 5 dx = ?",
      options: ["5 + C", "5x + C", "x/5 + C", "0"],
      correctAnswer: 1
    },
    {
      question: "∫ x² dx = ?",
      options: ["2x + C", "x³ + C", "x³/3 + C", "3x² + C"],
      correctAnswer: 2
    }
  ],
  partes: [
    {
      question: "En integración por partes, ∫ u dv = ?",
      options: ["uv + ∫ v du", "uv - ∫ v du", "u + v - ∫ du dv", "∫ u + ∫ dv"],
      correctAnswer: 1
    },
    {
      question: "Para ∫ x·eˣ dx, ¿qué elegimos como u?",
      options: ["eˣ", "x", "x·eˣ", "dx"],
      correctAnswer: 1
    },
    {
      question: "En ILATE, ¿qué tipo de función tiene mayor prioridad para u?",
      options: ["Exponencial", "Trigonométrica", "Inversa", "Algebraica"],
      correctAnswer: 2
    },
    {
      question: "Si u = ln(x), entonces du = ?",
      options: ["1/x dx", "x dx", "ln(x) dx", "1/ln(x) dx"],
      correctAnswer: 0
    },
    {
      question: "∫ x·sin(x) dx usando partes, elegimos u = x, entonces v = ?",
      options: ["sin(x)", "-cos(x)", "cos(x)", "x·sin(x)"],
      correctAnswer: 1
    }
  ],
  trigonometrica: [
    {
      question: "Para √(a² - x²), usamos la sustitución x = ?",
      options: ["a·tan(θ)", "a·sin(θ)", "a·sec(θ)", "a·cos(θ)"],
      correctAnswer: 1
    },
    {
      question: "Para √(a² + x²), usamos la sustitución x = ?",
      options: ["a·sin(θ)", "a·tan(θ)", "a·sec(θ)", "a·cot(θ)"],
      correctAnswer: 1
    },
    {
      question: "Si x = a·sin(θ), entonces dx = ?",
      options: ["a·sin(θ)dθ", "a·cos(θ)dθ", "sin(θ)dθ", "a·tan(θ)dθ"],
      correctAnswer: 1
    },
    {
      question: "Para √(x² - a²), usamos la sustitución x = ?",
      options: ["a·sin(θ)", "a·tan(θ)", "a·sec(θ)", "a·csc(θ)"],
      correctAnswer: 2
    },
    {
      question: "La identidad 1 + tan²(θ) = ?",
      options: ["sin²(θ)", "cos²(θ)", "sec²(θ)", "csc²(θ)"],
      correctAnswer: 2
    }
  ],
  parciales: [
    {
      question: "Para factores lineales distintos (x-a)(x-b), usamos: A/(x-a) + ?",
      options: ["A/(x-b)", "B/(x-b)", "Bx/(x-b)", "B(x-b)"],
      correctAnswer: 1
    },
    {
      question: "Si el denominador es (x-2)², ¿cuántos términos necesitamos?",
      options: ["1", "2", "3", "4"],
      correctAnswer: 1
    },
    {
      question: "Para un factor cuadrático irreducible x²+1, el numerador es:",
      options: ["A", "Ax", "Ax+B", "A+B"],
      correctAnswer: 2
    },
    {
      question: "El primer paso en fracciones parciales es:",
      options: ["Derivar", "Integrar", "Factorizar el denominador", "Sumar fracciones"],
      correctAnswer: 2
    },
    {
      question: "Si P(x)/(x-1)(x+2) = A/(x-1) + B/(x+2), ¿qué hacemos después?",
      options: ["Integrar ambos lados", "Derivar", "Multiplicar por (x-1)(x+2)", "Simplificar"],
      correctAnswer: 2
    }
  ],
  definida: [
    {
      question: "∫₀¹ x dx = ?",
      options: ["0", "1/2", "1", "2"],
      correctAnswer: 1
    },
    {
      question: "Si F'(x) = f(x), entonces ∫ₐᵇ f(x)dx = ?",
      options: ["F(a) - F(b)", "F(b) - F(a)", "F(a) + F(b)", "F(b)/F(a)"],
      correctAnswer: 1
    },
    {
      question: "∫ₐᵃ f(x)dx = ?",
      options: ["f(a)", "0", "2f(a)", "a"],
      correctAnswer: 1
    },
    {
      question: "Si ∫ₐᵇ f(x)dx = 5, entonces ∫ᵇₐ f(x)dx = ?",
      options: ["5", "-5", "10", "0"],
      correctAnswer: 1
    },
    {
      question: "La integral definida representa:",
      options: ["La derivada", "La pendiente", "El área bajo la curva", "El máximo"],
      correctAnswer: 2
    }
  ]
};

export default function QuizGame({ topic, user, onQuizComplete, onLogout }: QuizGameProps) {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showFeedback, setShowFeedback] = useState(false);
  const [score, setScore] = useState(0);
  const [answeredCorrectly, setAnsweredCorrectly] = useState<boolean[]>([]);

  const questions = quizQuestions[topic];
  const currentQuestion = questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / questions.length) * 100;

  const handleAnswerSelect = (answerIndex: number) => {
    if (showFeedback) return;

    setSelectedAnswer(answerIndex);
    setShowFeedback(true);

    const isCorrect = answerIndex === currentQuestion.correctAnswer;
    setAnsweredCorrectly([...answeredCorrectly, isCorrect]);

    if (isCorrect) {
      setScore(score + 20);
    }
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setSelectedAnswer(null);
      setShowFeedback(false);
    } else {
      // Quiz completed
      const finalScore = answeredCorrectly.filter(Boolean).length * 20;
      
      // Save result to localStorage
      const now = new Date();
      const dateStr = now.toLocaleDateString('es-ES', { 
        day: '2-digit', 
        month: 'short', 
        hour: '2-digit', 
        minute: '2-digit' 
      });
      
      saveQuizResult({
        studentName: user.name,
        studentEmail: user.email,
        topic,
        score: finalScore,
        date: dateStr
      });
      
      onQuizComplete(finalScore);
    }
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="bg-[#1A5490] text-white py-4 px-6 flex items-center justify-between">
        <div>
          <h1 className="mb-1">Interactivamente</h1>
          <p className="text-sm opacity-90">Modo: Estudiante - Juego de Integrales</p>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-sm">¡Hola, {user.name}!</span>
          <Button
            onClick={onLogout}
            variant="outline"
            className="bg-white/10 border-white/30 text-white hover:bg-white/20"
          >
            Cerrar Sesión
          </Button>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-3xl mx-auto p-8">
        {/* Progress */}
        <div className="mb-6">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-gray-700">
              Pregunta {currentQuestionIndex + 1} de {questions.length}
            </span>
            <span className="text-sm text-[#4CAF50]">
              Puntos: {score}
            </span>
          </div>
          <Progress value={progress} className="h-3" />
        </div>

        {/* Question Card */}
        <div className="bg-white rounded-2xl p-8 shadow-lg">
          <div className="mb-8">
            <h2 className="text-center text-[#1A5490] mb-6">Resuelve la integral:</h2>
            <div className="bg-gradient-to-r from-[#A8E6E3] to-[#C8F3F0] p-6 rounded-xl">
              <p className="font-serif text-center text-2xl">{currentQuestion.question}</p>
            </div>
          </div>

          {/* Options */}
          <div className="space-y-3">
            {currentQuestion.options.map((option, index) => {
              const isSelected = selectedAnswer === index;
              const isCorrect = index === currentQuestion.correctAnswer;
              const showAsCorrect = showFeedback && isCorrect;
              const showAsWrong = showFeedback && isSelected && !isCorrect;

              return (
                <button
                  key={index}
                  onClick={() => handleAnswerSelect(index)}
                  disabled={showFeedback}
                  className={`w-full p-4 rounded-lg border-2 transition-all text-left ${
                    showAsCorrect
                      ? "bg-green-100 border-green-500"
                      : showAsWrong
                      ? "bg-red-100 border-red-500"
                      : isSelected
                      ? "bg-blue-100 border-blue-500"
                      : "bg-white border-gray-300 hover:border-[#4CAF50] hover:bg-gray-50"
                  } ${showFeedback ? "cursor-not-allowed" : "cursor-pointer"}`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-serif">{option}</span>
                    {showAsCorrect && <span className="text-green-600">✓ Correcto</span>}
                    {showAsWrong && <span className="text-red-600">✗ Incorrecto</span>}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Feedback */}
          {showFeedback && (
            <div className="mt-6">
              {selectedAnswer === currentQuestion.correctAnswer ? (
                <div className="bg-green-50 border-2 border-green-500 rounded-lg p-4 text-center">
                  <p className="text-green-700 mb-2">
                    ¡Correcto! (ﾉ◕ヮ◕)ﾉ*:･ﾟ✧
                  </p>
                  <p className="text-sm text-green-600">+20 puntos</p>
                </div>
              ) : (
                <div className="bg-red-50 border-2 border-red-500 rounded-lg p-4 text-center">
                  <p className="text-red-700 mb-2">
                    No es correcto (╥_╥)
                  </p>
                  <p className="text-sm text-red-600">
                    La respuesta correcta era: <span className="font-serif font-bold">{currentQuestion.options[currentQuestion.correctAnswer]}</span>
                  </p>
                </div>
              )}

              <div className="mt-4 text-center">
                <Button
                  onClick={handleNextQuestion}
                  className="bg-[#4CAF50] hover:bg-[#45a049] text-white px-8 py-3 rounded-lg"
                >
                  {currentQuestionIndex < questions.length - 1 ? "Siguiente pregunta →" : "Ver resultados"}
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}