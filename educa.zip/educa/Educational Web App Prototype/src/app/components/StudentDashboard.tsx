import { Button } from "./ui/button";
import type { User } from "../App";

interface StudentDashboardProps {
  user: User;
  onBackToProfessor: () => void;
  onLogout: () => void;
}

export default function StudentDashboard({ user, onBackToProfessor, onLogout }: StudentDashboardProps) {
  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="bg-[#1A5490] text-white py-4 px-6 flex items-center justify-between">
        <div>
          <h1 className="mb-1">Interactivamente</h1>
          <p className="text-sm opacity-90">Vista de Estudiante (Modo Profesor)</p>
        </div>
        <div className="flex items-center gap-4">
          <Button
            onClick={onBackToProfessor}
            variant="outline"
            className="bg-white/10 border-white/30 text-white hover:bg-white/20"
          >
            ← Volver al panel de profesor
          </Button>
          <Button
            onClick={onLogout}
            variant="outline"
            className="bg-white/10 border-white/30 text-white hover:bg-white/20"
          >
            Cerrar Sesión
          </Button>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto p-8">
        <div className="bg-white rounded-2xl p-8 shadow-lg text-center">
          <span className="block text-6xl mb-6">(◠‿◠)</span>
          
          <h2 className="text-[#1A5490] mb-4">Vista de Estudiante</h2>
          
          <p className="text-gray-600 mb-6">
            Esta es una vista previa de cómo los estudiantes ven la aplicación.
            Para experimentar el juego completo, usa el botón "Volver al panel de profesor"
            y luego selecciona "Ver como estudiante" para navegar por todos los módulos.
          </p>

          <div className="bg-blue-50 p-6 rounded-lg border-l-4 border-blue-500 mb-6">
            <p className="text-blue-800 text-sm">
              💡 <strong>Funcionalidades del estudiante:</strong>
            </p>
            <ul className="text-left text-sm text-blue-700 mt-3 space-y-2 ml-6">
              <li>✓ Selección de temas de integración</li>
              <li>✓ Glosario con fórmulas y explicaciones</li>
              <li>✓ Juego de preguntas con retroalimentación inmediata</li>
              <li>✓ Sistema de puntuación y progreso</li>
              <li>✓ Resultados con mensajes motivadores (kaomojis)</li>
            </ul>
          </div>

          <Button
            onClick={onBackToProfessor}
            className="bg-[#7B2CBF] hover:bg-[#6A1FAF] text-white px-8 py-3 rounded-lg"
          >
            Regresar al Panel de Profesor
          </Button>
        </div>
      </div>
    </div>
  );
}
