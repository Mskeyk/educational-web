import { Button } from "./ui/button";
import type { Topic } from "../App";

interface QuizResultsProps {
  topic: Topic;
  score: number;
  onRetry: () => void;
  onBackToTopics: () => void;
  onLogout: () => void;
}

const topicNames: Record<Topic, string> = {
  antiderivadas: "Antiderivadas",
  partes: "Integración por Partes",
  trigonometrica: "Sustitución Trigonométrica",
  parciales: "Fracciones Parciales",
  definida: "Integral Definida"
};

const getPerformanceMessage = (score: number) => {
  if (score === 100) {
    return {
      emoji: "(ﾉ◕ヮ◕)ﾉ*:･ﾟ✧",
      message: "¡Perfecto! ¡Eres un maestro de las integrales!",
      color: "text-green-600"
    };
  } else if (score >= 80) {
    return {
      emoji: "(^▽^)",
      message: "¡Excelente trabajo! Dominas muy bien este tema",
      color: "text-green-600"
    };
  } else if (score >= 60) {
    return {
      emoji: "(｡◕‿◕｡)",
      message: "¡Buen trabajo! Sigue practicando para mejorar",
      color: "text-blue-600"
    };
  } else if (score >= 40) {
    return {
      emoji: "(◠‿◠)",
      message: "Vas por buen camino, pero necesitas más práctica",
      color: "text-yellow-600"
    };
  } else {
    return {
      emoji: "(╥_╥)",
      message: "No te desanimes, la práctica hace al maestro",
      color: "text-orange-600"
    };
  }
};

export default function QuizResults({ topic, score, onRetry, onBackToTopics, onLogout }: QuizResultsProps) {
  const performance = getPerformanceMessage(score);

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="bg-[#1A5490] text-white py-4 px-6 flex items-center justify-between">
        <div>
          <h1 className="mb-1">Interactivamente</h1>
          <p className="text-sm opacity-90">Modo: Estudiante - Resultados</p>
        </div>
        <div className="flex items-center gap-4">
          <Button
            onClick={onLogout}
            variant="outline"
            className="bg-white/10 border-white/30 text-white hover:bg-white/20"
          >
            Cerrar Sesión
          </Button>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-2xl mx-auto p-8">
        <div className="bg-white rounded-2xl p-8 shadow-lg text-center">
          <span className="block mb-6">{performance.emoji}</span>
          
          <h2 className="text-[#1A5490] mb-4">¡Juego completado!</h2>
          
          <div className="mb-6">
            <p className="text-gray-600 mb-2">Tema: {topicNames[topic]}</p>
          </div>

          {/* Score Display */}
          <div className="bg-gradient-to-r from-[#A8E6E3] to-[#C8F3F0] rounded-2xl p-8 mb-6">
            <p className="text-gray-700 mb-2">Tu puntuación:</p>
            <div className="mb-4">
              <span className="text-6xl text-[#1A5490]">{score}</span>
              <span className="text-2xl text-gray-600">/100</span>
            </div>
            <div className="w-full bg-white rounded-full h-4 overflow-hidden">
              <div
                className="bg-[#4CAF50] h-full transition-all duration-1000 rounded-full"
                style={{ width: `${score}%` }}
              />
            </div>
          </div>

          {/* Performance Message */}
          <div className="mb-8">
            <p className={`${performance.color}`}>{performance.message}</p>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              onClick={onRetry}
              className="bg-[#4CAF50] hover:bg-[#45a049] text-white px-6 py-3 rounded-lg"
            >
              🔄 Intentar de nuevo
            </Button>
            <Button
              onClick={onBackToTopics}
              variant="outline"
              className="border-2 border-[#1A5490] text-[#1A5490] hover:bg-[#1A5490] hover:text-white px-6 py-3 rounded-lg"
            >
              📚 Cambiar de tema
            </Button>
          </div>

          {/* Tip */}
          <div className="mt-8 p-4 bg-blue-50 rounded-lg border-l-4 border-blue-500">
            <p className="text-sm text-blue-800">
              💡 <strong>Consejo:</strong> Revisa el glosario antes de reintentar para reforzar los conceptos
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
