import { Button } from "./ui/button";
import type { User, Topic } from "../App";

interface TopicGlossaryProps {
  topic: Topic;
  user: User;
  onStartQuiz: () => void;
  onBack: () => void;
  onLogout: () => void;
}

const glossaryData: Record<Topic, {
  title: string;
  emoji: string;
  formulas: Array<{ name: string; formula: string; description: string }>;
}> = {
  antiderivadas: {
    title: "Antiderivadas",
    emoji: "(｡◕‿◕｡)",
    formulas: [
      {
        name: "Potencia",
        formula: "∫ xⁿ dx = (xⁿ⁺¹)/(n+1) + C",
        description: "Para n ≠ -1"
      },
      {
        name: "Exponencial",
        formula: "∫ eˣ dx = eˣ + C",
        description: "La exponencial es su propia antiderivada"
      },
      {
        name: "Logaritmo",
        formula: "∫ (1/x) dx = ln|x| + C",
        description: "Caso especial cuando n = -1"
      }
    ]
  },
  partes: {
    title: "Integración por Partes",
    emoji: "(^▽^)",
    formulas: [
      {
        name: "Fórmula principal",
        formula: "∫ u dv = uv - ∫ v du",
        description: "Elige u y dv apropiadamente"
      },
      {
        name: "Criterio ILATE",
        formula: "I: Inversa, L: Logarítmica, A: Algebraica, T: Trigonométrica, E: Exponencial",
        description: "Orden de prioridad para elegir u"
      }
    ]
  },
  trigonometrica: {
    title: "Sustitución Trigonométrica",
    emoji: "(◠‿◠)",
    formulas: [
      {
        name: "Raíz de a² - x²",
        formula: "x = a·sin(θ), dx = a·cos(θ)dθ",
        description: "Para √(a² - x²)"
      },
      {
        name: "Raíz de a² + x²",
        formula: "x = a·tan(θ), dx = a·sec²(θ)dθ",
        description: "Para √(a² + x²)"
      },
      {
        name: "Raíz de x² - a²",
        formula: "x = a·sec(θ), dx = a·sec(θ)tan(θ)dθ",
        description: "Para √(x² - a²)"
      }
    ]
  },
  parciales: {
    title: "Fracciones Parciales",
    emoji: "(✿◠‿◠)",
    formulas: [
      {
        name: "Factores lineales distintos",
        formula: "P(x)/[(x-a)(x-b)] = A/(x-a) + B/(x-b)",
        description: "Descomposición con factores simples"
      },
      {
        name: "Factores lineales repetidos",
        formula: "P(x)/(x-a)² = A/(x-a) + B/(x-a)²",
        description: "Cuando hay factores con multiplicidad"
      },
      {
        name: "Factor cuadrático irreducible",
        formula: "P(x)/[(x-a)(x²+bx+c)] = A/(x-a) + (Bx+C)/(x²+bx+c)",
        description: "Cuando aparecen factores cuadráticos"
      }
    ]
  },
  definida: {
    title: "Integral Definida",
    emoji: "(ﾉ◕ヮ◕)ﾉ*:･ﾟ✧",
    formulas: [
      {
        name: "Teorema Fundamental",
        formula: "∫ₐᵇ f(x)dx = F(b) - F(a)",
        description: "Donde F es antiderivada de f"
      },
      {
        name: "Área bajo la curva",
        formula: "A = ∫ₐᵇ f(x)dx",
        description: "Interpretación geométrica"
      },
      {
        name: "Propiedades",
        formula: "∫ₐᵇ f(x)dx = -∫ᵇₐ f(x)dx",
        description: "Cambio de límites invierte el signo"
      }
    ]
  }
};

export default function TopicGlossary({ topic, user, onStartQuiz, onBack, onLogout }: TopicGlossaryProps) {
  const glossary = glossaryData[topic];

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="bg-[#1A5490] text-white py-4 px-6 flex items-center justify-between">
        <div>
          <h1 className="mb-1">Interactivamente</h1>
          <p className="text-sm opacity-90">Modo: Estudiante</p>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-sm">¡Hola, {user.name}!</span>
          <Button
            onClick={onLogout}
            variant="outline"
            className="bg-white/10 border-white/30 text-white hover:bg-white/20"
          >
            Cerrar Sesión
          </Button>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto p-8">
        <div className="mb-6">
          <Button
            onClick={onBack}
            variant="outline"
            className="border-2 border-[#1A5490] text-[#1A5490] hover:bg-[#1A5490] hover:text-white"
          >
            ← Volver a temas
          </Button>
        </div>

        <div className="bg-white rounded-2xl p-8 shadow-lg mb-6">
          <div className="text-center mb-6">
            <span className="block mb-4">{glossary.emoji}</span>
            <h2 className="text-[#1A5490] mb-2">{glossary.title}</h2>
            <p className="text-gray-600">Fórmulas y conceptos principales</p>
          </div>

          <div className="space-y-6">
            {glossary.formulas.map((item, index) => (
              <div key={index} className="border-l-4 border-[#4CAF50] pl-6 py-2">
                <h3 className="text-[#1A5490] mb-2">{item.name}</h3>
                <div className="bg-gray-50 p-4 rounded-lg mb-2">
                  <p className="font-serif text-center">{item.formula}</p>
                </div>
                <p className="text-gray-600 text-sm italic">{item.description}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="flex gap-4 justify-center">
          <Button
            onClick={onStartQuiz}
            className="bg-[#4CAF50] hover:bg-[#45a049] text-white px-8 py-6 rounded-lg transition-colors"
          >
            ¡Practicar con el juego! (ﾉ◕ヮ◕)ﾉ*:･ﾟ✧
          </Button>
        </div>
      </div>
    </div>
  );
}
