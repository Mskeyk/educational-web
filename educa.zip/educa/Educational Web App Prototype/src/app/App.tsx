import { useState } from "react";
import LoginScreen from "./components/LoginScreen";
import StudentDashboard from "./components/StudentDashboard";
import ProfessorDashboard from "./components/ProfessorDashboard";
import TopicSelection from "./components/TopicSelection";
import TopicGlossary from "./components/TopicGlossary";
import QuizGame from "./components/QuizGame";
import QuizResults from "./components/QuizResults";

export type UserRole = "student" | "professor" | null;
export type Topic = "antiderivadas" | "partes" | "trigonometrica" | "parciales" | "definida";

export interface User {
  role: UserRole;
  name: string;
  email: string;
}

function App() {
  const [currentScreen, setCurrentScreen] = useState<string>("login");
  const [user, setUser] = useState<User | null>(null);
  const [selectedTopic, setSelectedTopic] = useState<Topic | null>(null);
  const [quizScore, setQuizScore] = useState<number>(0);

  const handleLogin = (role: UserRole, name: string, email: string) => {
    setUser({ role, name, email });
    if (role === "student") {
      setCurrentScreen("topic-selection");
    } else {
      setCurrentScreen("professor-dashboard");
    }
  };

  const handleLogout = () => {
    setUser(null);
    setCurrentScreen("login");
    setSelectedTopic(null);
  };

  const handleTopicSelect = (topic: Topic) => {
    setSelectedTopic(topic);
    setCurrentScreen("topic-glossary");
  };

  const handleStartQuiz = () => {
    setCurrentScreen("quiz-game");
  };

  const handleQuizComplete = (score: number) => {
    setQuizScore(score);
    setCurrentScreen("quiz-results");
  };

  const handleBackToTopics = () => {
    setSelectedTopic(null);
    setCurrentScreen("topic-selection");
  };

  const handleRetryQuiz = () => {
    setCurrentScreen("quiz-game");
  };

  const handleSwitchToStudentMode = () => {
    setCurrentScreen("topic-selection");
  };

  const handleBackToProfessorDashboard = () => {
    setCurrentScreen("professor-dashboard");
  };

  return (
    <div className="min-h-screen bg-[#A8E6E3]">
      {currentScreen === "login" && <LoginScreen onLogin={handleLogin} />}
      
      {currentScreen === "topic-selection" && user && (
        <TopicSelection
          user={user}
          onTopicSelect={handleTopicSelect}
          onLogout={handleLogout}
        />
      )}
      
      {currentScreen === "topic-glossary" && selectedTopic && user && (
        <TopicGlossary
          topic={selectedTopic}
          user={user}
          onStartQuiz={handleStartQuiz}
          onBack={handleBackToTopics}
          onLogout={handleLogout}
        />
      )}
      
      {currentScreen === "quiz-game" && selectedTopic && user && (
        <QuizGame
          topic={selectedTopic}
          user={user}
          onQuizComplete={handleQuizComplete}
          onLogout={handleLogout}
        />
      )}
      
      {currentScreen === "quiz-results" && selectedTopic && user && (
        <QuizResults
          topic={selectedTopic}
          score={quizScore}
          onRetry={handleRetryQuiz}
          onBackToTopics={handleBackToTopics}
          onLogout={handleLogout}
        />
      )}
      
      {currentScreen === "professor-dashboard" && user && (
        <ProfessorDashboard
          user={user}
          onLogout={handleLogout}
          onSwitchToStudentMode={handleSwitchToStudentMode}
        />
      )}
      
      {currentScreen === "student-dashboard" && user && (
        <StudentDashboard
          user={user}
          onBackToProfessor={handleBackToProfessorDashboard}
          onLogout={handleLogout}
        />
      )}
    </div>
  );
}

export default App;
