import type { Topic } from "../App";

export interface QuizResult {
  id: string;
  studentName: string;
  studentEmail: string;
  topic: Topic;
  score: number;
  date: string;
  timestamp: number;
}

const STORAGE_KEY = "interactivamente_results";

export const saveQuizResult = (result: Omit<QuizResult, "id" | "timestamp">): void => {
  try {
    const results = getQuizResults();
    const newResult: QuizResult = {
      ...result,
      id: `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      timestamp: Date.now()
    };
    results.push(newResult);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(results));
  } catch (error) {
    console.error("Error saving quiz result:", error);
  }
};

export const getQuizResults = (): QuizResult[] => {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error("Error getting quiz results:", error);
    return [];
  }
};

export const getTopStudents = (limit: number = 5): Array<{
  name: string;
  topic: string;
  score: number;
}> => {
  const results = getQuizResults();
  const topicNames: Record<Topic, string> = {
    antiderivadas: "Antiderivadas",
    partes: "Integración por Partes",
    trigonometrica: "Sustitución Trigonométrica",
    parciales: "Fracciones Parciales",
    definida: "Integral Definida"
  };

  // Get unique student-topic combinations with their best score
  const bestScores = new Map<string, QuizResult>();
  
  results.forEach(result => {
    const key = `${result.studentEmail}_${result.topic}`;
    const existing = bestScores.get(key);
    if (!existing || result.score > existing.score) {
      bestScores.set(key, result);
    }
  });

  // Sort by score and take top N
  return Array.from(bestScores.values())
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map(result => ({
      name: result.studentName,
      topic: topicNames[result.topic],
      score: result.score
    }));
};

export const getRecentResults = (limit: number = 5): Array<{
  name: string;
  topic: string;
  score: number;
  date: string;
}> => {
  const results = getQuizResults();
  const topicNames: Record<Topic, string> = {
    antiderivadas: "Antiderivadas",
    partes: "Integración por Partes",
    trigonometrica: "Sustitución Trigonométrica",
    parciales: "Fracciones Parciales",
    definida: "Integral Definida"
  };

  return results
    .sort((a, b) => b.timestamp - a.timestamp)
    .slice(0, limit)
    .map(result => ({
      name: result.studentName,
      topic: topicNames[result.topic],
      score: result.score,
      date: result.date
    }));
};

export const getStatistics = (): {
  totalStudents: number;
  activeStudents: number;
  groupAverage: number;
  recentVisits: number;
  topicStats: Array<{
    topic: string;
    average: number;
    attempts: number;
  }>;
} => {
  const results = getQuizResults();
  
  if (results.length === 0) {
    return {
      totalStudents: 0,
      activeStudents: 0,
      groupAverage: 0,
      recentVisits: 0,
      topicStats: []
    };
  }

  const uniqueStudents = new Set(results.map(r => r.studentEmail));
  const now = Date.now();
  const weekAgo = now - 7 * 24 * 60 * 60 * 1000;
  const activeStudents = new Set(
    results.filter(r => r.timestamp > weekAgo).map(r => r.studentEmail)
  );

  const dayAgo = now - 24 * 60 * 60 * 1000;
  const recentVisits = results.filter(r => r.timestamp > dayAgo).length;

  const totalScore = results.reduce((sum, r) => sum + r.score, 0);
  const groupAverage = Math.round(totalScore / results.length);

  const topicNames: Record<Topic, string> = {
    antiderivadas: "Antiderivadas",
    partes: "Integración por Partes",
    trigonometrica: "Sustitución Trigonométrica",
    parciales: "Fracciones Parciales",
    definida: "Integral Definida"
  };

  const topicGroups = results.reduce((acc, result) => {
    if (!acc[result.topic]) {
      acc[result.topic] = [];
    }
    acc[result.topic].push(result.score);
    return acc;
  }, {} as Record<Topic, number[]>);

  const topicStats = Object.entries(topicGroups).map(([topic, scores]) => ({
    topic: topicNames[topic as Topic],
    average: Math.round(scores.reduce((sum, s) => sum + s, 0) / scores.length),
    attempts: scores.length
  }));

  return {
    totalStudents: uniqueStudents.size,
    activeStudents: activeStudents.size,
    groupAverage,
    recentVisits,
    topicStats
  };
};
